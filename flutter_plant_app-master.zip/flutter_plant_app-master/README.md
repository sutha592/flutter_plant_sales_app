# Flutter Plant App


## Getting Started

![video 08](https://user-images.githubusercontent.com/33403844/152975357-dfeae391-e6bf-4392-97d5-fce229e8869d.png)
